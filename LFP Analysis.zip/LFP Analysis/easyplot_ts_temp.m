function [ plots ] = easyplot_ts_temp( varargin )
%easyplot_ts_temp Helper function for plotting structs containing signal/time
%series. Temp adds functionality related to control of y range. 
%  Takes custom time-series structs for easy plotting. 

% list of arrays for plotting
n_plots = nargin;
% figure;
plots = nan(n_plots,1);
plots_lim = nan(n_plots,4);


% step = 25;
% step = 5;

for i=1:n_plots
    plots(i) = subplot(n_plots,1,i);
    thisPlot = varargin{i};   % accepts time-series objects with .ts, .signal, .title fields.
    
    signal = thisPlot.signal;
    ts = thisPlot.ts;
    thisTitle = thisPlot.title;
    
    %scale the step by the total size, nte 25. could do this more
    %mathematically, but want to avoid excessive down-sampling on
    %time-series with few data points
%     if length(signal) > 10e5 
%         step = 25;
%     else step =1;
%     end

    if isfield(thisPlot,'stepsize')
        step = thisPlot.stepsize;
    else 
        step = 25;
    end
    
    plottype = nan;
    if isfield(thisPlot, 'plottype')
        plottype = thisPlot.plottype;
    end

    [x_t,y_t] =size(ts);
    [x_s,y_s] =size(signal);
    
    if ~islogical(signal) & isnan(plottype)

        if (x_t==x_s & y_t==y_s) | (x_t==y_s & x_s ==y_t)
            plot(ts(1:step:end),signal(1:step:end));
        else
            for i_s = 1:x_s    % there are multiple signals in the same trace
            plot(ts(1:step:end),signal(i_s,1:step:end));
            hold on;
            end
        end
        
        if isfield(thisPlot, 'refline_h')
            reflines = thisPlot.refline_h;
            hold on;
            for k=1:length(reflines)
                refline = reflines(k);
                line([0,length(signal)],[refline refline],'Color','red');
                %             line([0,length(signal)],[refline refline]);
            end
            hold off;
        end
    elseif strcmp (plottype, 'imagesc')
        
        if isfield(thisPlot,'imagerange')
        imagesc(ts(1:step:end),0:max(signal),signal(1:step:end)',thisPlot.imagerange);
                 colormap('hot');
        else
        imagesc(ts(1:step:end),0:max(signal),signal(1:step:end)');
        colormap('jet');
        end
        %         freezeColors(gca);
    else
        imagesc(ts(1:step:end),0:1,signal(1:step:end)');
        colormap('bone');
        %         freezeColors(gca);
    end
    
    ylabel(thisTitle,'FontSize',8);
    
    %     min_t = double(min(signal));
    %     max_t = double(max(signal));
   if ~islogical(signal) & ~isfield(thisPlot,'yrange')  % if signal is not logical and no range is predefined
        %         thisMean = median(signal);
        %         thisIQR = iqr(signal);
        %         disp('test');
        %         min_t = thisMean-2*thisIQR;
        %         max_t = thisMean+2*thisIQR;
        %
        if ~(x_s>1 & y_s >1)
            min_t = double(min(signal));
            max_t = double(max(signal));
        else   % account for non-singleton signal in some plots
            
            if (x_s < y_s)
                min_t = double(min(signal(1,:)));
                max_t = double(max(signal(1,:)));
            else
                min_t = double(min(signal(:,1)));
                max_t = double(max(signal(:,1)));
            end
        end
            
        
    else if isfield(thisPlot,'yrange')   % if we have pre-defined the y range
            
            min_t = thisPlot.yrange(1);
            max_t = thisPlot.yrange(2);
            
        else  %if logical and not predefined.
%             disp('else');
            min_t = double(min(signal));
            max_t = double(max(signal));
            
        end
    end
    
    
    plots_lim(i,:) = [min_t max_t ts(1) ts(end)];
    %     ylim([min_t max_t]);
end

linkaxes(plots,'x');
zoom xon;

% % if having
% if n_plots<2
%     plot_start =1;
% else
%     plot_start = 2;
% end

for i=1:n_plots
%     for i=2:n_plots
    thisAx = plots(i);
    try
        set(thisAx, 'ylim', [plots_lim(i,1:2)]);
    catch
        set(thisAx, 'ylim', [0 0.0001]);
    end
    
    set(thisAx, 'xlim', [plots_lim(i,3:4)]);
end
end


