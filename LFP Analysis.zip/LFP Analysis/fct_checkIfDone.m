function [ thisResult ] = fct_checkIfDone( thisFile, thisSubDirec )
%fct_checkIfDone 
% INPUT
%     thisFile, a struct generated from dir() with .name
%     thisSubDirec, a string referencing subdirectory where MAT file is saved
% 
% OUTPUT
%   thisResult, a table -- will be 'empty' if not done, otherwise contains
%   the table saved to disk as thisResult.

    filename = [thisFile.folder '/' thisSubDirec '/' thisFile.name '.mat'];

    thisFileOnDisk = dir(filename);
    if size(thisFileOnDisk,1)==1    % if the file is present
        S = load([thisFileOnDisk.folder '/' thisFileOnDisk.name]);
        thisResult = struct2table(S, 'AsArray', true);
    else if size(thisFileOnDisk,1)==0  % if the file is not there
        thisResult = table;
    end
    
end
