function [resultsTable] = run_eeg_v6(parentDir)
%% Spike detection for Zebrafish EEG
%v6. 22-10-31. adding support for multi-channel EEG.

% directories
addpath(parentDir);

formatOut = 'yy-mm-dd';
thisDate = datestr(now,formatOut);

%thisSubDir = [parentDir 'images_' thisDate '/'];
thisAnalysisDir = [parentDir 'analysis_' thisDate '/'];
thisSubDir = [thisAnalysisDir 'images/'];
make_directories({thisAnalysisDir, thisSubDir});
addpath(thisAnalysisDir);
addpath(thisSubDir);

graphicsFlag = true;
flag_useHPF = false;
loadFromMatlab = false;


%timeSegment = 0.75;  % the algorithm returns results for two epochs representing the 1st (X*100)% and the second (1-X)*100%
fs = 10000; % sampling freq = 10kHz

exptInfoTable = table;
% exptInfoTable.version = "V3. 6-30-22";
%exptInfoTable.version = "V4. 7-2-22";
%exptInfoTable.version = "V5. 7-11-22";
% exptInfoTable.version = "V5.2 8-25-22";
exptInfoTable.version = "V6 10-31-22";
exptInfoTable.fs_Hz = fs;
exptInfoTable.flag_useHPF = flag_useHPF;
exptInfoTable.loadFromMatlab = loadFromMatlab;

figInfoTable = {};

files = dir([parentDir '*.abf']);

%% Load XLS
exptXLS_filename = dir([parentDir 'expt_eeg_*.xlsx']);

if ~isempty(exptXLS_filename) && eq(length(exptXLS_filename),1)
    exptXLS = readtable([exptXLS_filename(1).folder '/' exptXLS_filename(1).name]);
else
    % may be empty or there are multiple XLSX documents
    warning('"expt_eeg*.xlsx not found or multiple XLSX documents -- only default epochs will be analyzed"')
    exptXLS=table;  % assign empty table.
end

%%

resultsTable = table;
resultsTable_extra = table;  % for extra user-defined segments

for j=1:length(files)
    
    fish =j;
    %%
    
    thisFile = files(fish);
    disp(thisFile.name);
    %     resultsTable_thisFish = table;
    
    % temp cludge
    %thisFile = dir('/mnt/NAS2_RAID/NAS/Data/Projects/Zebrafish EEG/CB Ephys/4.14.22 and 4.15.22 scn1lab x G005/2022_04_15_0001.abf');
    %parentDir = [thisFile.folder '/'];
    
    % check if done
    savedToDisk = fct_checkIfDone(thisFile,'mat');
    
    if ~isempty(savedToDisk) && loadFromMatlab
        %load the saved data
        rawEEG_s = savedToDisk.rawEEG_s;
        filtEEG_s_ma = savedToDisk.filtEEG_s_ma;
        spike_amp = savedToDisk.spike_amp;
        spike_rate_ts_miqr2 = savedToDisk.spike_rate_ts_miqr2;
        maxAmp = savedToDisk.maxAmp;
        totalPower = savedToDisk.totalPower;
        powerHigh = savedToDisk.powerHigh;
        powerLow = savedToDisk.powerLow;
        iqr_me_hilo = savedToDisk.iqr_me_hilo;
        fs2=1000;
        ts2=savedToDisk.ts2;
        spike_rate_ts_miqr2_gt04_d=savedToDisk.spike_rate_ts_miqr2_gt04_d;
        episode_stats_selected=savedToDisk.episode_stats_selected{1,1};
        
    else
        % if it hasn't been processed...
        abfload([parentDir thisFile.name],'info');
        [data_raw, si, h] = abfload([parentDir thisFile.name]);
        
        for i_chan = 1:size(data_raw,2)
            data = data_raw(1:end,i_chan);
            
            resultsTable_thisFish = table;
            % Down-sample
            fs2 = 1000;
            data_s = interp1([1:length(data)],data,[1:(fs/fs2):length(data)])';
            
            data_s_untruncated = data_s;
            %truncate in y, recenter, and normalize.
            %         data_s(data_s>1) = 1;
            %         data_s(data_s<-1) = -1;
            %data_s = (data_s-mean(data_s))./rms(data_s);
            data_s = (data_s-mean(data_s));
            
            ts = 0:1/fs:(length(data)-1)/fs;
            ts2 = 0:1/fs2:(length(data_s)-1)/fs2;
            
            rawEEG = struct('ts',ts, 'signal', data, 'title', 'raw eeg');
            
            % highpass filter the data -- 7-12-2022
            if flag_useHPF
                % apply a 0.5Hz high-pass filter
                data_s = eegfilt(data_s_untruncated',fs2, 0.5,0, 0,[],0,'fir1',0)';
                rawEEG_s = struct('ts',ts2, 'signal', data_s, 'title', 'raw eeg HPF');
                rawEEG_s.legend = 'Raw EEG after 0.5Hz high-pass filter applied using fir1/eegfilt()';
            else
                rawEEG_s = struct('ts',ts2, 'signal', data_s, 'title', 'raw eeg recentered');
                rawEEG_s.legend = 'Raw EEG, recentered by subtracting the mean';
            end
            
            %         figure; easyplot_ts_temp(rawEEG_s);
            %
            %         rawEEG_HPF = eegfilt(data_s_untruncated',fs2, 0.5,0, ...
            %                 0,[],0,'fir1',0);
            % % %         rawEEG_HPF = highpass(data_s_untruncated, 1,fs2,'ImpulseResponse','fir','Steepness',0.95);
            % %
            % % %         hpFilt = designfilt('highpassfir','FilterOrder',20, ...
            % % %                  'PassbandFrequency',0.1,'PassbandRipple',0.05, ...
            % % %                  'SampleRate',fs2);
            % % %
            % % %         hpFilt = designfilt('highpassfir', 'StopbandFrequency', ...
            % % %         .45, 'PassbandFrequency', .55, 'StopbandAttenuation', 60, ...
            % % %         'PassbandRipple', 0.01, 'SampleRate', 1000, 'DesignMethod', 'kaiserwin');
            % % %
            % % %         fvtool(hpFilt)
            % % %         rawEEG_HPF_IIR = filter(hpFilt,data_s_untruncated);
            % %         figure(2); plot(ts2, rawEEG_s.signal)
            %         figure(1); plot(ts2, rawEEG_HPF);
            %         f1=gca;
            %         figure(2); plot(ts2, data_s_untruncated);
            %         f2=gca;
            %         figure(3); plot(ts2, data_s_untruncated-smooth(data_s_untruncated, fs2*10));
            %         f3=gca;
            % %         figure(3); plot(ts2, data_s_untruncated-smooth(data_s_untruncated, fs2*10,'rloess'));
            %         figure(4); plot(ts2, smooth(rawEEG_HPF,10,'sgolay'));
            %         f4=gca;
            %         figure(5); plot(ts2, simplema(data_s_untruncated,fs2/10,1));
            %         f5=gca;
            % %         figure(6); plot(ts2, rawEEG_HPF_IIR);
            % %         f6=gca;
            %
            %         linkaxes([f1,f2,f3,f4,f5],'x');
            %
            %spectrogram
            [S,F,T,ps] = spectrogram(data_s,hanning(fs2*10),[],[0:0.1:120],fs2,'yaxis');
            %         spectrogram(data_s,hanning(fs2*10),[],[0:0.1:120],fs2,'yaxis');
            %         colormap('jet');
            
            %BP filter for these fat spikes in zebrafish
            thisFreq = [3,10];  %300msec - 100msec
            
            thisWvfm = data_s_untruncated;
            Fs = fs2;
            
            [z,p,k] = butter(6, [(thisFreq(1)-1)/(Fs/2),(thisFreq(2)+1)/(Fs/2)],'bandpass');
            %         [z,p,k] = butter(6, 1/(fs2/2),'high');
            [sos,g] = zp2sos(z,p,k);
            thisWvfm_bp = filtfilt(sos,g,thisWvfm);
            
            thisWvfm = thisWvfm_bp;
            figure; plot(ts2,thisWvfm);
            
            filtEEG_s =  struct('ts',ts2, 'signal', thisWvfm.^2, 'title', 'BPF eeg');
            filtEEG_s_ma= struct('ts', ts2, 'signal', simplema(filtEEG_s.signal,200,1), 'title','EEG filt ma');
            filtEEG_s_ma.legend = 'EEG, band-pass filtered (3-10Hz), squared, and smoothed using moving average with 0.2 second window';
            
            % iqr method
%             spikes = gt(abs(thisWvfm.^2), 24*iqr(thisWvfm.^2));
             spikes = gt(sqrt(thisWvfm.^2), 24*iqr(sqrt(thisWvfm.^2)));     % modifying 11-28-22
%             spikes = gt(abs(thisWvfm.^2), 24*iqr(thisWvfm.^2));
            
            spikes_ts = struct('ts',ts2, 'signal', logical(spikes), 'title', 'IQR spikes?');
            filtEEG_s.refline_h = 24*iqr(thisWvfm.^2);
            
            spike_rate = movsum(logical(spikes),20*fs2);
            
            spike_rate_ts = struct('ts',ts2, 'signal', spike_rate, 'title', 'spike rate');
            
            % moving estimate of IQR, crude
            window = 10*fs2;
            step = 1*fs2;   % will produce a time-series sampled q 1sec
            thisTS = filtEEG_s_ma.signal;
            
            iqr_ts = 1:step/fs2:ts2(end);   %samples
            iqr_me = zeros(length(iqr_ts),1);
            
            offset = window/2;
            
            for i=uint64(offset/step)+1:uint64(floor((length(ts2)-offset)/step))
                
                thisStart = step*(i-1)+1 -window/2;
                thisEnd = thisStart + window-1;
                
                thisSegment = thisTS(thisStart:thisEnd);
                thisResult = median(thisSegment) + iqr(thisSegment);
                
                iqr_me(i) = thisResult;
            end
            
            %upsample iqr_me to ts2.
            fs_me = fs2/step;
            fs2 = 1000;
            iqr_me_up = interp1([1:length(iqr_me)],iqr_me,[1:(fs_me/fs2):ts2(end)])';
            iqr_me_up_pad = zeros(length(ts2),1);
            iqr_me_up_pad( (1+step/2):length(iqr_me_up)+(step/2))=iqr_me_up(:); % recenter and pad with zero
            % can now be used with ts2
            
            iqr_ts_me = struct('ts',ts2, 'signal', iqr_me_up_pad, 'title', 'moving IQR', 'yrange',[0,1]);
            
            % high-low filtering
            iqr_me_lo= struct('ts', ts2, 'signal', gt(filtEEG_s_ma.signal, iqr_me_up_pad), 'title','> iqr');
            iqr_me_hi = struct('ts', ts2, 'signal', gt(filtEEG_s_ma.signal, iqr_me_up_pad*3), 'title','> iqr*3');
            
            indx1 = iqr_me_hi.signal;
            indx2 = iqr_me_lo.signal;
            
            stat_thresh_hi = regionprops(indx1,'area','PixelIdxList','BoundingBox');
            stat_thresh_lo = regionprops(indx2,'area','PixelIdxList','BoundingBox');
            
            indx_hi = cat(1, stat_thresh_hi.PixelIdxList);
            indx_lo = cat(1, stat_thresh_lo.PixelIdxList);
            
            isect = false(length(indx2),1);
            if ~isempty(indx_hi) & ~isempty(indx_lo)
                isect = bwselect([indx2 indx2], ones(length(indx_hi),1), indx_hi,4);   % must be 2D, order is critical, takes binary image but needs pixel ids for selection
                isect = isect(:,1);
            end
            
            iqr_me_hilo =  struct('ts', ts2, 'signal', isect, 'title','iqr me hi-lo');
            
            % count # of bars in iqr_me_hilo for accurate 'spike rate'
            indx1 = iqr_me_hilo.signal;
            stat = regionprops(indx1,'area','PixelIdxList','BoundingBox','Centroid');
            indx_count_centroid = cat(1, stat.Centroid);
            
            if ~isempty(indx_count_centroid)
                indx_count = indx_count_centroid(:,2);
                centroid_spikes = zeros(length(ts2),1);
                centroid_spikes(uint64(indx_count))=1;
            else
                indx_count=NaN;
                centroid_spikes = zeros(length(ts2),1);
            end
            
            spikes_ts_miqr_hilo_centroid = struct('ts', ts2, 'signal', logical(centroid_spikes), 'title','spikes miqr hilo centoid');
            % figure(9); easyplot_ts(rawEEG_s, filtEEG_s_ma, spikes_ts_miqr_hilo_centroid);
            
            % redo spike rate using new approach
            spikes_ts_miqr2 = struct('ts', ts2, 'signal', isect, 'title','spikes miqr hilo');
            
            %spike_rate_miqr2 = movsum(spikes_ts_miqr_hilo_centroid.signal,[5*fs2,5*fs2])/10;   % 10sec window, but recomputed /sec.
            spike_rate_miqr2 = movsum(spikes_ts_miqr_hilo_centroid.signal,[5*fs2,5*fs2])/10;   % 10sec window, but recomputed /sec.
            spike_rate_ts_miqr2 = struct('ts',ts2, 'signal', spike_rate_miqr2, 'title', 'spike rate mIQR hilo');
            spike_rate_ts_miqr2.legend = 'Spike rate computed using 10-second sliding window, 1-second step. Spikes detected using a sliding estimate of interquartile (IQR) range, 10 second window, 1 second step size, high-low threshold (3x>IQR to 1xIQR) based on EEG having been band-pass filtered (3-10Hz)';
            
            
            % figure; histogram(spike_rate_ts_miqr2.signal,20)
            % prctile(spike_rate_miqr2,95)
            
            %% find max amplitude of each spike
            thisCellArray = {stat.PixelIdxList};
            %maxAmp = cellfun( @(x) max(abs( rawEEG_s.signal(x))), thisCellArray, 'UniformOutput', false); 
            maxAmp = cellfun( @(x) max(abs( rawEEG_s.signal(x))), thisCellArray, 'UniformOutput', false);  % 11-28-22 editing to extract voltage from smoothed data
            maxAmp = cell2mat(maxAmp);
            if ~isnan(indx_count)
                centroid_spikes(uint64(indx_count))=maxAmp(:);
            end
            
            spike_amp = struct('ts', ts2, 'signal', centroid_spikes, 'title','spikes amplitude');
%             spike_amp.legend = 'Amplitude (mV) of detected spikes using moving IQR method';
            spike_amp.legend = 'Amplitude (mV) of detected spikes using moving IQR method';
            
            
            %% Find episodes with high # of spikes.
            % ts2 = filtEEG_s_ma.ts;
            % indx1 = iqr_me_hilo.signal;
            % stat = regionprops(indx1,'area','PixelIdxList','BoundingBox','Centroid');
            % indx_count_centroid = cat(1, stat.Centroid);
            % indx_count = indx_count_centroid(:,2);
            % centroid_spikes = zeros(length(ts2),1);
            % % round(rawEEG_s.ts(end))
            % centroid_spikes(uint64(indx_count))=1;
            %
            % spikes_ts_miqr_hilo_centroid = struct('ts', ts2, 'signal', logical(centroid_spikes), 'title','spikes miqr hilo centoid');
            % data is 'quantized' 0:0.1:1 (10-sec window)
            rawEEG_s_smooth = rawEEG_s;
            rawEEG_s_smooth.signal= smooth(rawEEG_s.signal,100);
            rawEEG_s_smooth.title = 'EEG smooth';
            rawEEG_s_smooth.legend = 'EEG smoothed using smooth(), 100 sample window';
            
            spike_rate_miqr2 = movsum(spikes_ts_miqr_hilo_centroid.signal,[5*fs2,5*fs2])/10;  % recalculate w 10sec window
            spike_rate_ts_miqr2_gt04 = struct('ts',ts2, 'signal', spike_rate_miqr2>0.3, 'title', 'spike rate >0.3');
            %spike_rate_ts_miqr2_gt04_amp_gt02 = struct('ts',ts2, 'signal', spike_rate_miqr2>0.4 & spike_amp.signal>0.2, 'title', 'spike rate mIQR hilo');
            
            % figure; easyplot_ts_temp(rawEEG_s, rawEEG_s_smooth,filtEEG_s_ma,spike_amp, spike_rate_ts_miqr2_gt04, spike_rate_ts_miqr2_gt04_amp_gt02,spike_rate_ts_miqr2)
            
            % figure; plot(ts2,rawEEG_s.signal);hold on;
            % plot(ts2,smooth(rawEEG_s.signal,100))
            
            % take original thresholded data, dilate it by 5 seconds, then do stats.
            spike_rate_ts_miqr2_gt04_ds = imdilate(spike_rate_ts_miqr2_gt04.signal,strel('line',5*fs2,90));
            spike_rate_ts_miqr2_gt04_d = spike_rate_ts_miqr2_gt04;
            spike_rate_ts_miqr2_gt04_d.signal = spike_rate_ts_miqr2_gt04_ds;
            
            % figure; easyplot_ts_temp(spike_rate_ts_miqr2_gt04, spike_rate_ts_miqr2_gt04_d);
            
            % obtain stats on dilated regions
            episode_stats = regionprops(spike_rate_ts_miqr2_gt04_d.signal,spike_amp.signal,'area','PixelIdxList','BoundingBox','Centroid','PixelValues');
            episode_stats_f = episode_stats(cat(1,episode_stats.Area)>1*fs2,:);  % select episodes greater than 1 second
            % figure; histogram(cat(1,episode_stats_f.Area),20);
            
            episode_stats_s = struct2cell(episode_stats_f)';
            episode_stats_spikeValues= cellfun(@(x) nonzeros(x), episode_stats_s(:,5),'UniformOutput',false);
            episode_stats_spikeCount = cellfun(@(x) length(nonzeros(x)), episode_stats_s(:,5),'UniformOutput',false);
            episode_stats_duration_sec = cellfun(@(x) (x)/fs2, episode_stats_s(:,1),'UniformOutput',false);
            episode_stats_centroid_sec = cellfun(@(x) (x(2))/fs2, episode_stats_s(:,2),'UniformOutput',false);
            episode_stats_s(:,6) = episode_stats_spikeValues;  % amplitude mV
            episode_stats_s(:,7) = episode_stats_spikeCount;   % # of spikes
            episode_stats_s(:,8) = episode_stats_duration_sec; % duration of episode sec
            episode_stats_s(:,9) = episode_stats_centroid_sec; % center of episode sec
            % recalculated "spike rate"
            episode_stats_s(:,10) = cellfun(@(x,y) x/y, episode_stats_s(:,7), episode_stats_s(:,8),'UniformOutput',false);
            % average spike amplitude
            episode_stats_s(:,11) = cellfun(@(x) mean(x), episode_stats_s(:,6),'UniformOutput',false);
            % median spike amplitude
            episode_stats_s(:,12) = cellfun(@(x) median(x), episode_stats_s(:,6),'UniformOutput',false);
            
            episode_stats_selected = episode_stats_s(cat(1,episode_stats_s{:,7})>3 & cat(1,episode_stats_s{:,10})>0.33,:);
            episode_stats_selected_log = zeros(length(ts2),1);
            episode_stats_selected_log(cat(1,episode_stats_selected{:,4}))=1;
            episode_stats_selected_avgAmp = zeros(length(ts2),1);
            episode_stats_selected_avgRate = zeros(length(ts2),1);
            episode_stats_selected_master = zeros(length(ts2),1);
            
            % for i=1:size(episode_stats_selected,1)
            % episode_stats_selected_avgAmp(episode_stats_selected{i,4})=episode_stats_selected{i,11};
            % episode_stats_selected_avgRate(episode_stats_selected{i,4})=episode_stats_selected{i,10};
            % end
            
            % generate a master map showing low vs high, and slow vs fast
            ampThresh=0.2; %(1 vs 2)
            rateThresh=0.4; % (3 vs 6)
            for i=1:size(episode_stats_selected,1)
                %thisAmpAvg = episode_stats_selected{i,11}>=ampThresh;
                thisAmpAvg = episode_stats_selected{i,12}>=ampThresh;  % using median spike amp
                thisRateAvg = episode_stats_selected{i,10}>=rateThresh;
                
                thisValue = (thisAmpAvg+1)+(thisRateAvg*3+3); % 4= low amp, low rate; 5 = high amp/lowrate; 7= low amp/high rate; 8=high amp/high rate
                episode_stats_selected_master(episode_stats_selected{i,4})=thisValue;
                episode_stats_selected_avgAmp(episode_stats_selected{i,4})=thisAmpAvg+1;
                episode_stats_selected_avgRate(episode_stats_selected{i,4})=thisRateAvg+1;
            end
            
            episode_stats_selected_ts = spike_rate_ts_miqr2_gt04_d;
            %episode_stats_selected_ts.signal = logical(episode_stats_selected_log);
            episode_stats_selected_ts.signal = episode_stats_selected_avgAmp;
            episode_stats_selected_ts.title = {'episodes >0.3Hz', '(< or > 0.2mV)'};
            episode_stats_selected_ts.plottype = 'imagesc';
            episode_stats_selected_ts.legend = 'episodes of bursts, with final spike rate >0.33Hz, colored by amplitude (1 = <0.2mV (orange), 2 = >=0.2mV (white))';
            
            episode_stats_selected_ts_Rate = episode_stats_selected_ts;
            episode_stats_selected_ts_Rate.signal = episode_stats_selected_avgRate;
            episode_stats_selected_ts_Rate.title = {'episodes >0.3Hz','(< or > 0.4Hz)'};
            episode_stats_selected_ts_Rate.legend = 'episodes of bursts, with final spike rate >0.33Hz, colored by rate (1 = 0.33-0.39Hz (orange), 2 = >=0.4Hz (white))';
            
            episode_stats_selected_ts.imagerange = [0,2];
            episode_stats_selected_ts_Rate.imagerange = [0,2];
            %episode_stats_selected_ts.imagerange = [];
            
            filtEEG_s_ma.refline_h = 2e-3;
            
            filtEEG_s_ma_thresh = struct('ts',ts2, 'signal', filtEEG_s_ma.signal>2e-3, 'title', 'spike rate mIQR hilo');
            
            thisSignal_n = abs(S);
            
            thisSignal_n_wide = sum(thisSignal_n,1);
            
            totalPower = struct('ts', T, 'signal', thisSignal_n_wide, 'title', 'power 0-120Hz');
            totalPower.stepsize = 1;
            
            thisEnd = find(F>1,1)-1;
            thisStart = find(F>0.05,1)-1;
            
            powerLow = struct('ts', T, 'signal', sum(thisSignal_n(thisStart:thisEnd,:),1), 'title', 'power, 0.05-1Hz');
            powerLow.stepsize = 1;
            powerLow.yrange =[0, 1500];
            
            % 7) high freq power (80-110 Hz)
            thisEnd = find(F>110,1)-1;
            thisStart = find(F>80,1)-1;
            
            % powerHigh = struct('ts', T, 'signal', sum(abs(S(thisStart:thisEnd,:)),1), 'title', 'power, 80-110Hz');
            powerHigh = struct('ts', T, 'signal', sum(thisSignal_n(thisStart:thisEnd,:),1), 'title', 'power, 80-110Hz');
            powerHigh.stepsize = 1;
            % powerHigh.yrange = [0, 1500];
            
            spike_amp.stepsize = 1;
            spike_amp.yrange = [0,1];
            spike_rate_ts_miqr2.yrange = [0,1];
            %spike_rate_ts_miqr2.yrange = [0,0.6];
            %filtEEG_s_ma.yrange = [0,1];
            
            if graphicsFlag
                % final figure
                %f1 = figure('Visible','on','Position',[0 0 1000 1000]);
                f1 = figure('Visible','off','Position',[0 0 1000 1000]);
                suptitle([replaceUnderscore(thisFile.name,'-','_') ' channel' num2str(i_chan)]); 
                %easyplot_ts_temp(rawEEG_s, filtEEG_s_ma, spike_amp, spike_rate_ts_miqr2, totalPower, powerLow, powerHigh);
                
                rangeForRawEEG_ymin = prctile(rawEEG_s.signal,0.1);
                rangeForRawEEG_ymax = prctile(rawEEG_s.signal,99.9);
                rawEEG_s.yrange = [rangeForRawEEG_ymin-0.1, rangeForRawEEG_ymax+0.1];
                
                rawEEG_s_smooth.yrange = [prctile(rawEEG_s_smooth.signal,0.1)-0.1,prctile(rawEEG_s_smooth.signal,99.9)+0.1];
                filtEEG_s_ma.yrange = [prctile(filtEEG_s_ma.signal,0.1)-0.1,prctile(filtEEG_s_ma.signal,99.9)+0.1];
                
                % easyplot_ts_temp(rawEEG_s, filtEEG_s_ma, spike_amp, spike_rate_ts_miqr2, totalPower, powerLow);
                easyplot_ts_temp(rawEEG_s, rawEEG_s_smooth,filtEEG_s_ma,spike_amp,...
                    episode_stats_selected_ts,episode_stats_selected_ts_Rate,spike_rate_ts_miqr2);

                
                
                set(f1,'visible','off');
                set(f1, 'PaperPositionMode','auto');
                
                print(f1, '-dpng','-zbuffer','-r300', [thisSubDir 'o-' thisFile.name '_c-' num2str(i_chan) '.png']);
                print(f1, '-dsvg','-zbuffer','-r300', [thisSubDir 'o-' thisFile.name '_c-' num2str(i_chan) '.svg']);
                print(f1, '-depsc','-zbuffer','-r300', [thisSubDir 'o-' thisFile.name '_c-' num2str(i_chan) '.eps']);
                
                close(f1);
                
                figInfoTable= fct_concatenateLegendInfo(rawEEG_s, rawEEG_s_smooth,filtEEG_s_ma,spike_amp,...
                    episode_stats_selected_ts,episode_stats_selected_ts_Rate,spike_rate_ts_miqr2);
                
            end
            %         end    commented 10-31-22
            %% output results to table
            
            timePt = round(rawEEG_s.ts(end)); %seconds; total length
            time_buffer = 3*60; %seconds
            time1_start = time_buffer;
            time1_end = timePt - time_buffer;
            
            %timeStep = 1800; % seconds; length of epoch to analyze
            %timeStep2 = 120; % seconds; offset from time of PTZ application.
            
            % generate table of epochs, all equal length, throw out remaining data at the end
            epochLength_sec = 5*60; % 5min
            numEpochs = floor((timePt-time_buffer*2)/epochLength_sec);
            
            theseEpochs = table;
            for p=1:numEpochs
                thisEpoch =table;
                thisEpoch.epochNum = p;
                thisEpoch.time1_start = time_buffer+epochLength_sec*(p-1);
                %         if p<numEpochs
                thisEpoch.time1_end = time_buffer + epochLength_sec*p-1;
                %         else
                %             thisEpoch.time1_end = timePt-time_buffer;
                %         end
                thisEpoch.time_length = thisEpoch.time1_end - thisEpoch.time1_start;
                theseEpochs= cat(1,theseEpochs, thisEpoch);
            end
            
            thisEpoch_az = table;
            thisEpoch_az.epochNum = 0;
            thisEpoch_az = cat(2, thisEpoch_az, [theseEpochs(1,2) theseEpochs(end,3)]);
            thisEpoch_az.time_length = thisEpoch_az.time1_end - thisEpoch_az.time1_start;
            theseEpochs = cat(1,theseEpochs, thisEpoch_az);
            
            %%% custom epoch "99": start  --> end 
            thisEpoch_az = table;
            thisEpoch_az.epochNum = 99;
            thisEpoch_az = cat(2, thisEpoch_az, theseEpochs(1,2));
            
            customEndTime = 28*60; %28 minutes
            if customEndTime < time1_end
                thisEpoch_az.time1_end = customEndTime;
            else
                thisEpoch_az.time1_end = time1_end;
            end
            thisEpoch_az.time_length = thisEpoch_az.time1_end - thisEpoch_az.time1_start;
            theseEpochs = cat(1,theseEpochs, thisEpoch_az);
            
            %%% custom epoch "100": 32min --> end
            thisEpoch_az = table;
            thisEpoch_az.epochNum = 100;
            thisEpoch_az = cat(2, thisEpoch_az, theseEpochs(1,2));
            
            thisEpoch_az.time1_start = 30*60; % 30min
            customEndTime =60*60; %60 minutes
            if customEndTime < time1_end
                thisEpoch_az.time1_end = customEndTime;
            else
                thisEpoch_az.time1_end = time1_end;
            end           
           
            thisEpoch_az.time_length = thisEpoch_az.time1_end - thisEpoch_az.time1_start;
            theseEpochs = cat(1,theseEpochs, thisEpoch_az);

            % check that these times are not too short
            theseEpochs_clean = fct_checkValidEpochs(theseEpochs,time1_start, time1_end);
            theseEpochs=theseEpochs_clean; 

            for p=1:size(theseEpochs,1)
                
                thisEpoch = theseEpochs(p,:);
                time1_start = thisEpoch.time1_start;
                time1_end = thisEpoch.time1_end;
                
                thisResult = table;
                thisResult.id = j;
                thisResult.chan = i_chan;
                thisResult.file = {thisFile.name};
                thisResult.recording_duration_sec = timePt;
                thisResult = cat(2,thisResult, thisEpoch);
                %         thisResult.epochNum = p;
                %         thisResult.timeSegment_prct = timeSegment*100;
                %         thisResult.time1_start = time1_start;
                %         thisResult.time1_end = time1_end;
                %         thisResult.time2_start = time2_start;
                %         thisResult.time2_end = time2_end;
                
                %only compute on non-zero data
                indx_nz = eq(spike_amp.signal,0);
                spike_amp_nonzero = spike_amp.signal;
                spike_amp_nonzero(indx_nz) = nan;
                
                maxAmp1 = spike_amp_nonzero( (time1_start)*fs2 : (time1_end)*fs2 );
                maxAmp1 = maxAmp1(~isnan(maxAmp1));
                
                thisResult.spike_count_1 = {length(maxAmp1)};
                
                %segment1
                if length(maxAmp1)>=5  % need 5+ data points
                    
                    [N,edges] = histcounts(maxAmp1,100);
                    edges_fix = edges(1:end-1)+diff(edges)/2;
                    [pHat,pCI] = lognfit(edges_fix,.05,[],N);
                    
                    thisResult.spike_amp_1_lognormal_mu = {pHat(1)};
                    thisResult.spike_amp_1_lognormal_sigma = {pHat(2)};
                    thisResult.spike_amp_1_lognormal_mu_CI = {pCI(:,1)};
                    thisResult.spike_amp_1_lognormal_sigma_CI = {pCI(:,2)};
                    thisResult.spike_amp_1_lognormal_exp_threshold = {exp(pHat(1)+(pHat(2)))};
                    
                else
                    %if <5 spikes counted, don't fit the data.
                    thisResult.spike_amp_1_lognormal_mu = {nan};
                    thisResult.spike_amp_1_lognormal_sigma = {nan};
                    thisResult.spike_amp_1_lognormal_mu_CI = {[nan,nan]};
                    thisResult.spike_amp_1_lognormal_sigma_CI = {[nan,nan]};
                    thisResult.spike_amp_1_lognormal_exp_threshold = {nan};
                end
                
                thisResult.spike_amp_1_mean = {mean(maxAmp1)};
                thisResult.spike_amp_1_median = {median(maxAmp1)};
                thisResult.spike_amp_1_prctle95 = {prctile(maxAmp1,95)};
                thisResult.spike_amp_1_prct_gt_0_2mV = {sum(maxAmp1>0.2)/length(maxAmp1)};
                
                %% spike rate
                
                thisResult.spike_rate_1 = {mean( spike_rate_ts_miqr2.signal( (time1_start)*fs2 : (time1_end)*fs2 ))};
                
                indx1 = iqr_me_hilo.signal( (time1_start)*fs2 : (time1_end)*fs2 );
                eeg_1 = abs(rawEEG_s.signal( (time1_start)*fs2 : (time1_end)*fs2 ));
                
                stat = regionprops(indx1,eeg_1,'area','PixelIdxList','BoundingBox','Centroid','MaxIntensity');
                indx_count_centroid = cat(1, stat.Centroid);
                indx_count_amp = abs(cat(1, stat.MaxIntensity));
                if ~isempty(indx_count_centroid)
                    indx_spikes = [indx_count_centroid indx_count_amp indx_count_centroid(:,2)/fs2];
                    %indx_spikes_big = indx_spikes(indx_spikes(:,3)>=median(maxAmp),:);  %global maxAmp
                else
                    indx_spikes = indx_count_centroid;
                end
                
                if ~isempty(indx_spikes) && length(indx_spikes)>=5
                    spike_isi = diff(indx_spikes(:,2))/fs2;
                    indx_spikes = [indx_spikes [spike_isi;0] 1./[spike_isi;0]];
                    [isi,edges] = histcounts(spike_isi,100);
                    edges_fix = edges(1:end-1)+diff(edges)/2;
                    [phat,pci] = gamfit(edges_fix,.05,[],isi);
                    
                    thisResult.isi_gamma_1_a_shape = {phat(1)};
                    thisResult.isi_gamma_1_b_scale = {phat(2)};
                    thisResult.isi_gamma_1_a_CI = {pci(:,1)};
                    thisResult.isi_gamma_1_b_CI = {pci(:,2)};
                else
                    thisResult.isi_gamma_1_a_shape = {nan};
                    thisResult.isi_gamma_1_b_scale = {nan};
                    thisResult.isi_gamma_1_a_CI = {[nan,nan]};
                    thisResult.isi_gamma_1_b_CI = {[nan,nan]};
                    
                end
                
                thisResult.power_total_1 = {mean( totalPower.signal( round(time1_start/5) : round(time1_end/5) ))};
                thisResult.power_low_1 = {mean( powerLow.signal( round(time1_start/5) : round(time1_end/5) ))};
                thisResult.power_hi_1 = {mean( powerHigh.signal( round(time1_start/5) : round(time1_end/5) ))};
                
                %% Statistics related to episodes of high frequency bursts
                % obtain stats on dilated regions
                
                % take original thresholded data, dilate it by 5 seconds, then do stats.
                thisSegment =  spike_rate_ts_miqr2_gt04_d.signal((time1_start)*fs2 : (time1_end)*fs2);
                thisSpikeAmpSegment = spike_amp.signal((time1_start)*fs2 : (time1_end)*fs2);
                episode_stats = regionprops(thisSegment,thisSpikeAmpSegment,'area','PixelIdxList','BoundingBox','Centroid','PixelValues');
                episode_stats_f = episode_stats(cat(1,episode_stats.Area)>1*fs2,:);  % select episodes greater than 1 second
                % figure; histogram(cat(1,episode_stats_f.Area),20);
                
                episode_stats_s = struct2cell(episode_stats_f)';
                episode_stats_spikeValues= cellfun(@(x) nonzeros(x), episode_stats_s(:,5),'UniformOutput',false);
                episode_stats_spikeCount = cellfun(@(x) length(nonzeros(x)), episode_stats_s(:,5),'UniformOutput',false);
                episode_stats_duration_sec = cellfun(@(x) (x)/fs2, episode_stats_s(:,1),'UniformOutput',false);
                episode_stats_centroid_sec = cellfun(@(x) (x(2))/fs2, episode_stats_s(:,2),'UniformOutput',false);
                episode_stats_s(:,6) = episode_stats_spikeValues;  % amplitude mV
                episode_stats_s(:,7) = episode_stats_spikeCount;   % # of spikes
                episode_stats_s(:,8) = episode_stats_duration_sec; % duration of episode sec
                episode_stats_s(:,9) = episode_stats_centroid_sec; % center of episode sec
                % recalculated "spike rate"
                episode_stats_s(:,10) = cellfun(@(x,y) x/y, episode_stats_s(:,7), episode_stats_s(:,8),'UniformOutput',false);
                % average spike amplitude
                episode_stats_s(:,11) = cellfun(@(x) mean(x), episode_stats_s(:,6),'UniformOutput',false);
                
                episode_stats_selected = episode_stats_s(cat(1,episode_stats_s{:,7})>3 & cat(1,episode_stats_s{:,10})>0.33,:);
                
                thisResult.episodes_total_criteria = {'>1sec, >3 spikes, rate >0.3 (prelim), final rate>0.33'};
                % can filter episodes into total, low vs high, and slow vs fast
                if ~isempty(episode_stats_selected)
                    thisResult.episodes_total_count = {size(episode_stats_selected,1)};
                    thisResult.episodes_total_duration_sec = {sum(cat(1,episode_stats_selected{:,8}))};
                    thisResult.episodes_total_duration_avg_sec = {mean(cat(1,episode_stats_selected{:,8}))};
                    thisResult.episodes_total_spikeRate_avg_Hz = {mean(cat(1,episode_stats_selected{:,10}))};
                    thisResult.episodes_total_amplitude_avg_mV = {mean(cat(1,episode_stats_selected{:,11}))};
                else
                    % fill w nan
                    thisResult.episodes_total_count = {0};
                    thisResult.episodes_total_duration_sec = {0};
                    thisResult.episodes_total_duration_avg_sec = {nan};
                    thisResult.episodes_total_spikeRate_avg_Hz = {nan};
                    thisResult.episodes_total_amplitude_avg_mV = {nan};
                end
                
                thisResult.episodes_lowAmp_criteria = {'>1sec, >3 spikes, rate >0.3 (prelim), final rate>0.33, avg amp <0.2mV'};
                ep_st_s_low = episode_stats_selected(cat(1,episode_stats_selected{:,11})<0.2,:);
                if ~isempty(ep_st_s_low)
                    thisResult.episodes_lowAmp_count = {size(ep_st_s_low,1)};
                    thisResult.episodes_lowAmp_duration_sec = {sum(cat(1,ep_st_s_low{:,8}))};
                    thisResult.episodes_lowAmp_duration_avg_sec = {mean(cat(1,ep_st_s_low{:,8}))};
                    thisResult.episodes_lowAmp_spikeRate_avg_Hz = {mean(cat(1,ep_st_s_low{:,10}))};
                    thisResult.episodes_lowAmp_amplitude_avg_mV = {mean(cat(1,ep_st_s_low{:,11}))};
                else
                    % fill w nan
                    thisResult.episodes_lowAmp_count = {0};
                    thisResult.episodes_lowAmp_duration_sec = {0};
                    thisResult.episodes_lowAmp_duration_avg_sec = {nan};
                    thisResult.episodes_lowAmp_spikeRate_avg_Hz = {nan};
                    thisResult.episodes_lowAmp_amplitude_avg_mV = {nan};
                end
                
                thisResult.episodes_highAmp_criteria = {'>1sec, >3 spikes, rate >0.3 (prelim), final rate>0.33, avg amp >=0.2mV'};
                ep_st_s_hi = episode_stats_selected(cat(1,episode_stats_selected{:,11})>=0.2,:);
                
                if ~isempty(ep_st_s_hi)
                    thisResult.episodes_highAmp_count = {size(ep_st_s_hi,1)};
                    thisResult.episodes_highAmp_duration_sec = {sum(cat(1,ep_st_s_hi{:,8}))};
                    thisResult.episodes_highAmp_duration_avg_sec = {mean(cat(1,ep_st_s_hi{:,8}))};
                    thisResult.episodes_highAmp_spikeRate_avg_Hz = {mean(cat(1,ep_st_s_hi{:,10}))};
                    thisResult.episodes_highAmp_amplitude_avg_mV = {mean(cat(1,ep_st_s_hi{:,11}))};
                else
                    % fill w nan
                    thisResult.episodes_highAmp_count = {0};
                    thisResult.episodes_highAmp_duration_sec = {0};
                    thisResult.episodes_highAmp_duration_avg_sec = {nan};
                    thisResult.episodes_highAmp_spikeRate_avg_Hz = {nan};
                    thisResult.episodes_highAmp_amplitude_avg_mV = {nan};
                end
                
                resultsTable_thisFish = cat(1, resultsTable_thisFish, thisResult);
                
            end
            
            resultsTable = cat(1, resultsTable, resultsTable_thisFish);
            
            %% save data to disk
            if isempty(savedToDisk)
                matDirec= [thisFile.folder '/mat'];
                make_directories({matDirec});
                save([matDirec '/' thisFile.name '.mat'], 'ts2','fs2','rawEEG_s', 'rawEEG_s_smooth','filtEEG_s_ma', 'iqr_me_hilo', 'spike_amp', ...
                    'spike_rate_ts_miqr2_gt04_d', 'spike_rate_ts_miqr2', 'maxAmp', 'totalPower','powerHigh','powerLow', ...
                    'episode_stats_selected',  'episode_stats_selected_ts', 'episode_stats_selected_ts_Rate', '-v7.3','-nocompression')
            end
        end    % adding 10-31-22
    end
    
    %% write resultsTable to file 
    
    writetable(resultsTable, [thisAnalysisDir 'results_v5.xlsx'],'Sheet','Results_default');
    if ~isempty(resultsTable_extra)
        writetable(resultsTable_extra, [thisAnalysisDir 'results_v5.xlsx'],'Sheet','Results_extra');
    end
    
    writetable(exptInfoTable, [thisAnalysisDir 'results_v5.xlsx'],'Sheet','expt info');
    
    writecell(figInfoTable, [thisAnalysisDir 'results_v5.xlsx'],'Sheet','figure info');
    
    %     writecell(figInfoTable, 'results_v5_figureInfo.csv');
    
    
end
end
