function [theseEpochs_clean] = fct_checkValidEpochs(theseEpochs,time1_start, time1_end)
%fct_checkValidEpochs  Remove and give warnings for epochs that are invalid based on time start/end.

theseEpochs_clean = table; 

for j=1:size(theseEpochs,1)

    thisEpoch = theseEpochs(j,:); 
    % 3 possibilities -- 
    % 1) start is too early --> default to time1_start 
    % 2) start is too late --> delete epoch 
    % 3) end is too late --> default to time1_end 
    
    if thisEpoch.time1_start < time1_start 
        warning('Invalid epoch time: start time is before beginning of ABF file. Revising to be start of ABF');
        thisEpoch.time1_start = time1_start;
    end

    if thisEpoch.time1_start >time1_end  
        warning('Invalid epoch time: start time is after end of ABF file. Skipping...');
        continue 
    end

    if thisEpoch.time1_end > time1_end
        warning('Invalid epoch time: end time is after and of ABF file. Revising to be end of ABF');
        thisEpoch.time1_end = time1_end; 
    end

    theseEpochs_clean = cat(1, theseEpochs_clean, thisEpoch);  % having been revised, or this gets skipped. 

end 

%theseEpoch_clean = theseEpoch_clean(tablefun(@x, isempty(x), theseEpoch_clean.time1_start));


end

