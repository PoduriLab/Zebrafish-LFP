function goodString = replaceUnderscore( badString, substChar0, badChar0 )
% Replace underscores with some desired character.
% V2. handles cell arrays of strings in addition to strings

badChar = '_';   %default char to replace
substChar = '-'; %default char for substitution

i=0;
while i <= nargin
    switch i
        case 0
            % bad, but too lazy to add error msg
        case 2
            substChar = substChar0;
        case 3
            badChar = badChar0;
    end
    i=i+1;
end

% if the string to be modified is actually a cell array of strings
if iscell(badString)
    
    goodString = cell(length(badString),1);
    for j = 1:length(badString)
        thisString = badString{j};
        goodString{j} = replace(thisString,badChar,substChar);
    end
   
% if the string to be modified is indeed a single string
else if ischar(badString)
        
        goodString = replace(badString,badChar,substChar);
        
    end
end
end

function gS = replace (badString,badChar,substChar)
Lia = ismember(badString, badChar);


if ~isempty(substChar)
    badString(Lia)=substChar;
    gS = badString;
else
    % substChar is just '' so remove *** will change the length of the
    % string
    loc = find(Lia);
    
    for f=1:length(loc)
        thisLoc = loc(f);
        
        if eq(thisLoc,length(badString))
            badString = badString(1:thisLoc-1);
        elseif eq(thisLoc,1)
            badString = badString(2:end);
            loc = loc-1;  %update loc list after destructive modification of string
        else
            % location is somewhere in the middle
            badString = [badString(1:thisLoc-1) badString(thisLoc+1:end)];
            loc = loc-1; %update loc list after destructive modification of string
        end
    end
    
    gS = badString;
end

end
