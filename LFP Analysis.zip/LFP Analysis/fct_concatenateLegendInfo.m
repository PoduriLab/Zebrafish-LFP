function [tableEntry] = fct_concatenateLegendInfo(varargin)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
n_plots = nargin;
tableEntry = cell(n_plots,3);

for i=1:n_plots
    thisPlot = varargin{i};
    tableEntry{i,1} = num2str(i);
    if iscell(thisPlot.title)
        thisTitle = [thisPlot.title{:}];
    else
        thisTitle = thisPlot.title;
    end
    tableEntry{i,2} = thisTitle;
    
    if isfield(thisPlot,'legend')
        thisLegend = thisPlot.legend;
    else
        thisLegend = '';
    end
    tableEntry{i,3} = thisLegend;
    
end

% a= cat(1,tableEntry(:))';

% tableEntry = a;

end

