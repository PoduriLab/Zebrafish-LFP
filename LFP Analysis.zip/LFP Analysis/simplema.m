function thisSignal_ma_all = simplema( thisSignal, thisWindow, dim)
%SIMPLEMA Returns simple 1D moving average of signal based on defined window.
% INPUT
%   thisSignal      : 1D array of time series data.
%   thisWindow      : uint specifying number of samples for moving average.
%   dim             : int, specifying dimension or direction of average
% OUTPUT
%   thisSignal_ma   : moving average of thisSignal, trimmed to original
%                       dimensions.

winElement = thisWindow;
windowKernel = ones(1,winElement)/winElement;

% assume 2D -- if other dimension, transpose.
if dim == 2
    thisSignal = thisSignal';
end
sig_size = size(thisSignal); 

% dim_iter = [2,1]; % the other dimension to choose for iteration
thisSignal_ma_all = zeros(sig_size(1),sig_size(2));

for i_d = 1:sig_size(2)
 
thisSignal_slice = thisSignal(:,i_d);    
thisSignal_ma = conv(thisSignal_slice,windowKernel);   % single channel
thisSignal_ma = thisSignal_ma(ceil(winElement/2):end-floor(winElement/2),:);  % trim edges

thisSignal_ma_all(:,i_d) = thisSignal_ma;

end

if dim ==2
    thisSignal_ma_all = thisSignal_ma_all';
end

end

